package com.greatbank.transactionprocessor;

/**
 * @author Sinto
 *
 */
public interface TaskExecutor {
	public void execute();
}
